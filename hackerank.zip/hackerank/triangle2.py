for i in range(1,int(input())+1): 
    print(pow(((pow(10,i)-1)//9),2))
